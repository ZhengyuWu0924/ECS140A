/* All novels published either during the year 1953 or during the year 1996*/
year_1953_1996_novels(Book) :-
    %% remove fail and add body/other cases for this predicate
    fail.

/* List of all novels published during the period 1800 to 1900 (not inclusive)*/
period_1800_1900_novels(Book) :-
    %% remove fail and add body/other cases for this predicate
    fail.

/* Characters who are fans of LOTR */
lotr_fans(Fan) :-
    %% remove fail and add body/other cases for this predicate
    fail.

/* Authors of the novels that heckles is fan of. */
heckles_idols(Author) :-
    %% remove fail and add body/other cases for this predicate
    fail.

/* Characters who are fans of any of Robert Heinlein's novels */
heinlein_fans(Fan) :-
    %% remove fail and add body/other cases for this predicate
    fail.

/* Novels common between either of Phoebe, Ross, and Monica */
mutual_novels(Book) :-
    %% remove fail and add body/other cases for this predicate
    fail.
