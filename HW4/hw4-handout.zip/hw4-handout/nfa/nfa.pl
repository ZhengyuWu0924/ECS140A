reachable(Nfa, StartState, FinalState, Input) :-
    %% TODO: remove fail and add body/other cases for this predicate
    fail.
